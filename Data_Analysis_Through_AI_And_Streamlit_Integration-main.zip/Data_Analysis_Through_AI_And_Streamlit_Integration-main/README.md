# Data-Analysis-Through-AI-and-Streamlit-Integration

## run the code
   ```
    streamlit run .\final_code.py 
   ```

