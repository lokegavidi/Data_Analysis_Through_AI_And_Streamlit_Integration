# Data-Analysis-Through-AI-and-Streamlit-Integration

## run the code
   ```
    streamlit run app_DS.py --server.enableXsrfProtection false
   ```

